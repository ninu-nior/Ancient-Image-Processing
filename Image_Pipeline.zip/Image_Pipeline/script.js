function uploadImage() {
    let input = document.getElementById('imageInput');
    if (input.files.length === 0) {
        alert("Please select an image.");
        return;
    }
    
    let formData = new FormData();
    formData.append("image", input.files[0]);
    
    let previewDiv = document.getElementById("preview");
    let outputDiv = document.getElementById("output");
    previewDiv.innerHTML = "<p>Uploading...</p>";
    outputDiv.innerHTML = "";
    
    fetch("http://127.0.0.1:5000/api/upload", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert("Error: " + data.error);
            return;
        }
        
        previewDiv.innerHTML = `<h3>Uploaded Image:</h3><img src="${URL.createObjectURL(input.files[0])}" alt="Uploaded Image" class="preview-img">`;
        outputDiv.innerHTML = `<h3>Processed Images:</h3><p>${data.description}</p><p><strong>Detected Language:</strong> ${data.language}</p>`;
        
        let imageContainer = document.createElement("div");
        imageContainer.classList.add("image-grid");
        
        let imageLabels = data.image_labels || []; // Fallback if image_labels is undefined
        
        data.images.forEach((imgUrl, index) => {
            let imgWrapper = document.createElement("div");
            imgWrapper.classList.add("image-wrapper");
            
            let imgElement = document.createElement("img");
            imgElement.src = "http://127.0.0.1:5000" + imgUrl;
            imgElement.classList.add("processed-img-large");
            
            let label = document.createElement("p");
            label.textContent = imageLabels[index] || "Processed Image";
            label.classList.add("image-label");
            
            imgWrapper.appendChild(imgElement);
            imgWrapper.appendChild(label);
            imageContainer.appendChild(imgWrapper);
        });
        
        outputDiv.appendChild(imageContainer);
    })
    .catch(error => {
        console.error("Error:", error);
        previewDiv.innerHTML = "<p>Failed to upload image.</p>";
    });
}
